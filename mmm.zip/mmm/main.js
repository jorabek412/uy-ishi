const form = document.querySelector(".form-group");
let input = document.querySelector("#nameInput");
const wrapper = document.querySelector(".wrapper");
let button = document.querySelector(".btn");

button.addEventListener("click", function (e) {
  e.preventDefault();
  fetch(`https://api.nationalize.io/?name=${input.value}`)
    .then((response) => response.json())
    .then((data) => {
      let allData = data.country;
      wrapper.innerHTML = "";
      let ol = document.createElement("ol");
      wrapper.appendChild(ol);
      allData.forEach((item) => {
        let li = document.createElement("li");
        let img = document.createElement("img");
        img.setAttribute(
          "src",
          `https://flagcdn.com/16x12/${item.country_id.toLowerCase()}.png`
        );
        let p = document.createElement("p");
        p.textContent = `Probability: ${Math.round(item.probability * 100)}%`;
        li.append(img, p);
        ol.appendChild(li);
      });
    });
});

form.addEventListener("submit", function (e) {
  e.preventDefault();
  button.click();
});
